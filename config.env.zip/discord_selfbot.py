import discord
import asyncio
import logging
import os
import aiohttp
import json
import time
import sys
from datetime import datetime
from dotenv import load_dotenv

# Custom StreamHandler that handles Unicode encoding errors on Windows
class SafeStreamHandler(logging.StreamHandler):
    def emit(self, record):
        try:
            msg = self.format(record)
            stream = self.stream
            # Try to write with error handling for Windows console encoding issues
            try:
                stream.write(msg + self.terminator)
            except (UnicodeEncodeError, UnicodeError):
                # If encoding fails (e.g., cp1252 can't handle emojis), replace problematic characters
                # Encode to the stream's encoding with error replacement, then decode back
                encoding = getattr(stream, 'encoding', 'utf-8') or 'utf-8'
                try:
                    safe_msg = msg.encode(encoding, errors='replace').decode(encoding)
                    stream.write(safe_msg + self.terminator)
                except Exception:
                    # Last resort: use ASCII with replacement
                    safe_msg = msg.encode('ascii', errors='replace').decode('ascii')
                    stream.write(safe_msg + self.terminator)
            self.flush()
        except Exception:
            self.handleError(record)

# Set up basic logging first (before we try to use it)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        SafeStreamHandler(sys.stdout)  # Console handler with Unicode safety
    ]
)

# Load environment variables from config.env file
load_dotenv('config.env')

# Configuration from environment
DISCORD_TOKEN = os.getenv('DISCORD_TOKEN', '').strip()
ROVER_BOT_ID = int(os.getenv('ROVER_BOT_ID', '298796807323123712'))
TARGET_SERVER_ID = int(os.getenv('TARGET_SERVER_ID', '1429900376861315277'))
USERIDS_FILE = os.getenv('USERIDS_FILE', 'userids.txt')
WEBHOOK_URL = os.getenv('WEBHOOK_URL')
PRIVATE_INVENTORY_WEBHOOK_URL = os.getenv('PRIVATE_INVENTORY_WEBHOOK_URL')
VALUE_THRESHOLD = int(os.getenv('VALUE_THRESHOLD', '1000'))
MAX_TRADE_ADS = int(os.getenv('MAX_TRADE_ADS', '1000'))

# No file logging - console only

# Verify which discord library is being used
discord_path = discord.__file__ if hasattr(discord, '__file__') else 'Unknown'
logging.info(f"Discord library path: {discord_path}")
if 'discord.py-self' in discord_path.lower() or 'discord_self' in discord_path.lower():
    logging.info("✓ Using discord.py-self library")
else:
    logging.warning("⚠ May be using regular discord.py instead of discord.py-self")
    logging.warning("  This can cause token validation issues. Ensure discord.py-self is installed.")

class DiscordSelfbot(discord.Client):
    def __init__(self):
        # discord.py-self doesn't use intents - initialize without them
        super().__init__()
        self.rover_bot_id = int(ROVER_BOT_ID)
        self.processed_users = set()  # Track users we've already sent Rover commands for
        self.webhook_sent_users = set()  # Track users we've already sent webhooks for
        self.processing_queue = asyncio.Queue()  # Queue for users to process
        self.queue_processor_running = False
        self.user_id_to_line_map = {}  # Map user IDs to their original line in file (for deletion)
        
    async def on_ready(self):
        logging.info(f'Logged in as {self.user}')
        logging.info('Starting user processing from userids.txt')
        logging.info(f'📊 Configuration: VALUE_THRESHOLD={VALUE_THRESHOLD:,}, MAX_TRADE_ADS={MAX_TRADE_ADS}')
        
        # Start the queue processor if not already running
        if not self.queue_processor_running:
            self.queue_processor_running = True
            asyncio.create_task(self.process_queue())
            # Load users from file and add to queue
            asyncio.create_task(self.load_users_from_file())
    
    async def load_users_from_file(self):
        """Load user IDs from userids.txt and add them to the processing queue"""
        try:
            if not os.path.exists(USERIDS_FILE):
                logging.error(f"User IDs file not found: {USERIDS_FILE}")
                return
            
            # Read all lines and track which line each user ID is on
            lines = []
            user_ids = []
            with open(USERIDS_FILE, 'r') as f:
                lines = f.readlines()
            
            for line_num, line in enumerate(lines):
                original_line = line
                line = line.strip()
                # Skip empty lines and comments
                if not line or line.startswith('#'):
                    continue
                try:
                    user_id = int(line)
                    user_ids.append(user_id)
                    # Store the mapping of user_id to line number and original line
                    self.user_id_to_line_map[user_id] = (line_num, original_line)
                except ValueError:
                    logging.warning(f"Invalid user ID in file: {line}")
                    continue
            
            logging.info(f"Loaded {len(user_ids)} user IDs from {USERIDS_FILE}")
            
            # Add users to queue
            for user_id in user_ids:
                if user_id not in self.processed_users:
                    # Create a simple user object with just the ID (we'll get name from Rover if needed)
                    class SimpleUser:
                        def __init__(self, user_id):
                            self.id = user_id
                            self.name = f"User_{user_id}"  # Placeholder, will be updated from Rover response
                    
                    user = SimpleUser(user_id)
                    self.processed_users.add(user_id)
                    await self.processing_queue.put((user, "PENDING", None, user_id))
                else:
                    # Remove from file if already processed
                    await self.remove_user_id_from_file(user_id)
        except Exception as e:
            logging.error(f"Error loading users from file: {e}")
            import traceback
            logging.error(traceback.format_exc())
    
    async def remove_user_id_from_file(self, user_id):
        """Remove a user ID from the userids.txt file after processing"""
        try:
            if not os.path.exists(USERIDS_FILE):
                return
            
            # Read all lines
            with open(USERIDS_FILE, 'r') as f:
                lines = f.readlines()
            
            # Filter out the line containing this user ID
            user_id_str = str(user_id)
            filtered_lines = []
            removed = False
            
            for line in lines:
                stripped = line.strip()
                # Keep the line if it doesn't match the user ID (and preserve comments/empty lines)
                if stripped != user_id_str:
                    filtered_lines.append(line)
                else:
                    removed = True
                    # Also remove from mapping if it exists
                    if user_id in self.user_id_to_line_map:
                        del self.user_id_to_line_map[user_id]
            
                # Write back to file only if we removed something
                if removed:
                    with open(USERIDS_FILE, 'w') as f:
                        f.writelines(filtered_lines)
        except Exception as e:
            logging.error(f"Error removing user ID {user_id} from file: {e}")
    
    
    async def process_queue(self):
        """Process users from the queue one at a time with delays"""
        while self.queue_processor_running:
            try:
                # Wait for a user to process (with timeout to check if we should stop)
                try:
                    user_data = await asyncio.wait_for(self.processing_queue.get(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue  # Check if we should stop and try again
                
                # Unpack user data (now includes user_id)
                if len(user_data) == 4:
                    user, message_count, message, user_id = user_data
                else:
                    # Fallback for old format
                    user, message_count, message = user_data
                    user_id = user.id if hasattr(user, 'id') else None
                
                # Process the user directly (no message count check needed)
                await self.log_user_and_get_roblox(user, 0, None)
                
                # Remove user ID from file after processing
                if user_id:
                    await self.remove_user_id_from_file(user_id)
                
                # Wait 2.5-3.5 seconds before processing next user
                delay = 2.5 + (1 * (self.processing_queue.qsize() > 3))  # 2.5s normally, 3.5s if queue is busy
                await asyncio.sleep(delay)
                
            except Exception as e:
                logging.error(f"Error in queue processor: {e}")
                await asyncio.sleep(5)  # Wait before retrying
    
    async def log_user_and_get_roblox(self, user, message_count, message=None):
        """Log user information and attempt to get Roblox account via Rover bot"""
        try:
            # Try to get Roblox account via Rover bot
            await self.get_roblox_account(user)
            
        except Exception as e:
            logging.error(f"Error processing user {user.name}: {e}")
    
    async def get_roblox_account(self, user):
        """Use Rover bot to get Roblox account information"""
        try:
            # Get the target server
            target_server = self.get_guild(TARGET_SERVER_ID)
            if not target_server:
                logging.error(f"Target server {TARGET_SERVER_ID} not found. Available servers: {[guild.id for guild in self.guilds]}")
                return
            
            logging.info(f"Found target server: {target_server.name}")
            
            # Check if Rover bot is in the server
            rover_member = target_server.get_member(self.rover_bot_id)
            if not rover_member:
                logging.error(f"Rover bot not found in server {target_server.name}")
                return
            else:
                logging.info(f"Found Rover bot: {rover_member.name}")
            
            # Find a suitable channel in the target server
            channel = None
            for ch in target_server.text_channels:
                try:
                    # Check if we can send messages and if Rover bot is present
                    if (ch.permissions_for(target_server.me).send_messages and 
                        self.rover_bot_id in [member.id for member in target_server.members]):
                        channel = ch
                        break
                except:
                    continue
            
            if not channel:
                logging.warning(f"No suitable channel found in server {target_server.name} to send Rover command")
                return
            
            try:
                # Send slash command interaction directly via HTTP API
                await self.send_rover_slash_command(channel, user)
                
                # Wait for Rover bot response
                def check_response(m):
                    return (m.author.id == self.rover_bot_id and 
                           m.channel.id == channel.id)
                
                try:
                    response = await self.wait_for('message', check=check_response, timeout=30)
                    # Extract Roblox user ID from Rover's response and get Rolimons data
                    await self.get_rolimons_data(user, response)
                    
                except asyncio.TimeoutError:
                    pass  # Silently handle timeout
                    
            except Exception as e:
                logging.error(f"Error sending Rover command for {user.name} (ID: {user.id}): {e}")
                
        except Exception as e:
            logging.error(f"Error getting Roblox account for {user.name}: {e}")
    
    async def send_rover_slash_command(self, channel, user):
        """Send Rover bot slash command using exact payload structure"""
        try:
            # Create the exact payload structure from your example
            payload = {
                "type": 2,
                "application_id": "298796807323123712",
                "guild_id": str(TARGET_SERVER_ID),
                "channel_id": str(channel.id),
                "data": {
                    "version": "1076786613092364290",
                    "id": "977319353156526141",
                    "name": "whois",
                    "type": 1,
                    "options": [
                        {
                            "type": 1,
                            "name": "discord",
                            "options": [
                                {
                                    "type": 6,
                                    "name": "user",
                                    "value": str(user.id)
                                }
                            ]
                        }
                    ]
                },
                "nonce": str(int(datetime.now().timestamp() * 1000)),
                "session_id": "838f52e4e8680620625b562ac77f422d"
            }
            
            headers = {
                'Authorization': DISCORD_TOKEN,
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    'https://discord.com/api/v9/interactions',
                    headers=headers,
                    json=payload
                ) as response:
                    if response.status not in [200, 204]:
                        response_text = await response.text()
                        logging.error(f"Failed to send Rover command: {response.status} - {response_text}")
                        
        except Exception as e:
            logging.error(f"Error sending Rover slash command: {e}")
    
    async def get_rolimons_data(self, discord_user, rover_response):
        """Extract Roblox user ID from Rover response and get Rolimons data"""
        try:
            # Try to extract Discord username from Rover response and update user object
            self.extract_discord_username_from_rover(discord_user, rover_response)
            
            # Extract Roblox user ID from Rover's response
            roblox_user_id = self.extract_roblox_id_from_message(rover_response)
            
            if roblox_user_id:
                # Get Rolimons data
                await self.fetch_rolimons_info(discord_user, roblox_user_id)
            else:
                logging.warning(f"Could not extract Roblox ID from Rover response")
                
        except Exception as e:
            logging.error(f"Error getting Rolimons data for {discord_user.name}: {e}")
    
    def extract_discord_username_from_rover(self, discord_user, message):
        """Extract Discord username from Rover response and update user object"""
        try:
            import re
            
            # Try to extract from embeds
            if message.embeds:
                for embed in message.embeds:
                    embed_dict = embed.to_dict()
                    
                    # First, check the embed title - Rover often puts Discord username at the top
                    if 'title' in embed_dict and embed_dict['title']:
                        title = embed_dict['title']
                        # Look for username pattern in title (e.g., "jakidz#0" or just "jakidz")
                        # Username format: alphanumeric + underscore, optionally followed by # and discriminator
                        username_match = re.search(r'([a-zA-Z0-9_]+)(?:#\d+)?', title)
                        if username_match:
                            username = username_match.group(1).strip()
                            if username and not username.startswith('User_') and len(username) > 2:
                                discord_user.name = username
                                logging.info(f"✅ Extracted Discord username from embed title: {username}")
                                return
                    
                    # Check embed author name (Rover might put username here)
                    if 'author' in embed_dict:
                        author = embed_dict['author']
                        if 'name' in author:
                            author_name = author['name']
                            # Check if it's a username pattern (not bot name)
                            if not any(bot_word in author_name.lower() for bot_word in ['bot', 'rover', 'system', 'rover']):
                                # Extract username (might be "username#discriminator")
                                username = author_name.split('#')[0].strip()
                                username = re.sub(r'[`*_~@]', '', username).strip()
                                if username and not username.startswith('User_') and len(username) > 2:
                                    discord_user.name = username
                                    return
                    
                    # Look in embed description - check the first line which often has Discord username
                    if 'description' in embed_dict and embed_dict['description']:
                        description = embed_dict['description']
                        # Get first line of description
                        first_line = description.split('\n')[0] if '\n' in description else description
                        # Try to find username pattern at start of description
                        # Pattern: username#discriminator or just username
                        username_match = re.search(r'^([a-zA-Z0-9_]+)(?:#\d+)?', first_line)
                        if username_match:
                            username = username_match.group(1).strip()
                            if username and not username.startswith('User_') and len(username) > 2:
                                discord_user.name = username
                                return
                        
                        # Also try patterns for "Discord Username: ..." format
                        patterns = [
                            r'Discord.*?Username[:\s]+([a-zA-Z0-9_]+)(?:#\d+)?',
                            r'Username[:\s]+([a-zA-Z0-9_]+)(?:#\d+)?',
                        ]
                        
                        for pattern in patterns:
                            match = re.search(pattern, description, re.IGNORECASE)
                            if match:
                                username = match.group(1).strip()
                                username = re.sub(r'[`*_~@]', '', username).strip()
                                if username and username != 'Unknown' and not username.startswith('User_') and len(username) > 2:
                                    discord_user.name = username
                                    return
                    
                    # Look in embed fields - check all fields for username patterns
                    if 'fields' in embed_dict:
                        for field in embed_dict['fields']:
                            if 'name' in field and 'value' in field:
                                field_name = field['name'].lower()
                                field_value = field['value']
                                
                                # Check if this field contains Discord username info
                                if ('discord' in field_name and 'username' in field_name) or \
                                   (field_name == 'username' and 'discord' in field_value.lower()) or \
                                   ('discord' in field_name and 'user' in field_name):
                                    # Extract username from field value
                                    # Format might be "username", "username#discriminator", or "@username"
                                    username = field_value.strip()
                                    # Remove @ if present
                                    if username.startswith('@'):
                                        username = username[1:]
                                    # Split on # to get just username part
                                    username = username.split('#')[0].strip()
                                    # Remove any markdown formatting
                                    username = re.sub(r'[`*_~]', '', username).strip()
                                    if username and username != 'Unknown' and not username.startswith('User_') and len(username) > 2:
                                        discord_user.name = username
                                        return
                    
                    # Check embed footer as last resort
                    if 'footer' in embed_dict and 'text' in embed_dict['footer']:
                        footer_text = embed_dict['footer']['text']
                        username_match = re.search(r'([a-zA-Z0-9_]+)(?:#\d+)?', footer_text)
                        if username_match:
                            username = username_match.group(1).strip()
                            if username and not username.startswith('User_') and len(username) > 2:
                                discord_user.name = username
                                return
            
            # Fallback: try to extract from message content
            if message.content:
                # Try to find username pattern in content
                username_match = re.search(r'([a-zA-Z0-9_]+)(?:#\d+)?', message.content)
                if username_match:
                    username = username_match.group(1).strip()
                    username = re.sub(r'[`*_~@]', '', username).strip()
                    if username and username != 'Unknown' and not username.startswith('User_') and len(username) > 2:
                        discord_user.name = username
                        return
                
                # Also try structured patterns
                patterns = [
                    r'Discord.*?Username[:\s]+([a-zA-Z0-9_]+)(?:#\d+)?',
                    r'Username[:\s]+([a-zA-Z0-9_]+)(?:#\d+)?',
                ]
                
                for pattern in patterns:
                    match = re.search(pattern, message.content, re.IGNORECASE)
                    if match:
                        username = match.group(1).strip()
                        username = re.sub(r'[`*_~@]', '', username).strip()
                        if username and username != 'Unknown' and not username.startswith('User_') and len(username) > 2:
                            discord_user.name = username
                            return
            
            # Username extraction failed - will use placeholder
            pass
        except Exception as e:
            logging.error(f"Error extracting Discord username from Rover response: {e}")
            import traceback
            logging.error(traceback.format_exc())
    
    def extract_roblox_id_from_message(self, message):
        """Extract Roblox user ID from Rover bot Discord message"""
        try:
            import re
            
            # First try to extract from embeds
            if message.embeds:
                for embed in message.embeds:
                    embed_dict = embed.to_dict()
                    
                    # Look in embed fields
                    if 'fields' in embed_dict:
                        for field in embed_dict['fields']:
                            if 'name' in field and 'value' in field:
                                field_name = field['name'].lower()
                                field_value = field['value']
                                
                                if 'roblox user id' in field_name or 'user id' in field_name:
                                    # Extract number from field value
                                    match = re.search(r'(\d+)', field_value)
                                    if match:
                                        return match.group(1)
                    
                    # Look in embed description
                    if 'description' in embed_dict:
                        match = re.search(r'(\d{6,})', embed_dict['description'])
                        if match:
                            return match.group(1)
            
            # Fallback: try to extract from message content
            if message.content:
                patterns = [
                    r'"Roblox user ID":\s*"(\d+)"',  # "Roblox user ID": "296077611"
                    r'Roblox user ID[:\s]*(\d+)',     # "Roblox user ID: 296077611"
                    r'user ID[:\s]*(\d+)',           # "user ID: 296077611"
                    r'ID[:\s]*(\d+)',                # "ID: 296077611"
                    r'(\d{6,})'                      # Any 6+ digit number
                ]
                
                for pattern in patterns:
                    match = re.search(pattern, message.content, re.IGNORECASE)
                    if match:
                        roblox_id = match.group(1)
                        if len(roblox_id) >= 6:
                            return roblox_id
            
            return None
            
        except Exception as e:
            logging.error(f"Error extracting Roblox ID from message: {e}")
            return None
    
    async def fetch_rolimons_info(self, discord_user, roblox_user_id):
        """Fetch inventory value and trade ads from Rolimons API"""
        try:
            url = f"https://api.rolimons.com/players/v1/playerinfo/{roblox_user_id}"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        # Removed verbose API logging for cleaner console
                        
                        # Use API data as primary source, fallback to scraping for trade ads
                        inventory_value = data.get('value', 'Unknown')
                        rap_value = data.get('rap', 'Unknown')
                        username = data.get('name', 'Unknown')
                        
                        # Try to get trade ads via web scraping (fallback if API doesn't have it)
                        trade_ads = await self.get_trade_ads_from_scraping(roblox_user_id)
                        
                        # Determine if inventory is private based on API response
                        is_private_inventory = inventory_value == 'Unknown' or inventory_value is None
                        
                        # Convert string values to numbers for processing
                        if inventory_value == 'Unknown' or inventory_value is None:
                            inventory_value = 0  # Treat unknown/None as 0 for webhook display
                        elif isinstance(inventory_value, str) and inventory_value.isdigit():
                            inventory_value = int(inventory_value)
                        elif not isinstance(inventory_value, (int, float)):
                            # If it's some other type we can't handle, set to 0
                            inventory_value = 0
                        
                        # Removed verbose Rolimons data logging for cleaner console
                        
                        # Check if user meets criteria and send appropriate webhook (only once per user)
                        user_key = f"{discord_user.id}_{roblox_user_id}"  # Unique key for Discord user + Roblox ID
                        
                        if user_key not in self.webhook_sent_users:
                            self.webhook_sent_users.add(user_key)
                            
                            # Check trade ads filter first
                            if trade_ads > MAX_TRADE_ADS:
                                return
                            
                            # Determine which webhook to send based on inventory status
                            if is_private_inventory:
                                # Private inventory (Unknown value) - send to separate channel
                                if PRIVATE_INVENTORY_WEBHOOK_URL and PRIVATE_INVENTORY_WEBHOOK_URL != 'https://discord.com/api/webhooks/YOUR_PRIVATE_WEBHOOK_URL_HERE':
                                    await self.send_webhook(discord_user, username, roblox_user_id, inventory_value, rap_value, trade_ads, is_private_inventory, is_private=True)
                            elif isinstance(inventory_value, (int, float)) and inventory_value >= VALUE_THRESHOLD:
                                # Public inventory with high value - send to main channel
                                await self.send_webhook(discord_user, username, roblox_user_id, inventory_value, rap_value, trade_ads, is_private_inventory, is_private=False)
                        
                    else:
                        response_text = await response.text()
                        logging.error(f"Failed to fetch Rolimons data for Roblox ID {roblox_user_id}: {response.status} - {response_text}")
                        
        except Exception as e:
            logging.error(f"Error fetching Rolimons data for Roblox ID {roblox_user_id}: {e}")
    
    async def get_trade_ads_from_scraping(self, roblox_user_id):
        """Get trade ads count by scraping Rolimons website (fallback method)"""
        try:
            # Try different URL formats
            urls_to_try = [
                f"https://rolimons.com/player/{roblox_user_id}",
                f"https://rolimons.com/players/{roblox_user_id}",
                f"https://www.rolimons.com/player/{roblox_user_id}",
                f"https://www.rolimons.com/players/{roblox_user_id}"
            ]
            
            async with aiohttp.ClientSession() as session:
                for url in urls_to_try:
                    try:
                        async with session.get(url) as response:
                            if response.status == 200:
                                html_content = await response.text()
                                
                                # Removed verbose HTML logging for cleaner console
                                
                                # Look for trade ads count in the HTML
                                import re
                                
                                # First, try to extract just the trade ads section
                                trade_ads_section_match = re.search(r'<div[^>]*trade-ads-created-container[^>]*>.*?</div>', html_content, re.DOTALL | re.IGNORECASE)
                                if trade_ads_section_match:
                                    trade_ads_section = trade_ads_section_match.group(0)
                                    
                                    # Look for number in the trade ads section only
                                    section_patterns = [
                                        r'<span[^>]*stat-data[^>]*>([\d,]+)</span>',
                                        r'<span[^>]*>([\d,]+)</span>',
                                        r'>([\d,]+)<'
                                    ]
                                    
                                    for i, pattern in enumerate(section_patterns):
                                        matches = re.findall(pattern, trade_ads_section)
                                        if matches:
                                            # Remove commas from the number before converting to int
                                            trade_count = int(matches[0].replace(',', ''))
                                            break
                                
                                # Fallback to full page patterns if section extraction failed
                                if trade_count is None:
                                    # More specific patterns - look for the actual trade ads count section
                                    patterns = [
                                        r'trade-ads-created-container[^>]*>.*?<span[^>]*stat-data[^>]*>([\d,]+)</span>',
                                        r'Trade Ads Created[^>]*>.*?<span[^>]*stat-data[^>]*>([\d,]+)</span>',
                                        r'<div[^>]*trade-ads-created-container[^>]*>.*?<span[^>]*>([\d,]+)</span>',
                                        r'Trade Ads Created.*?<span[^>]*class="[^"]*stat-data[^"]*"[^>]*>([\d,]+)</span>',
                                        r'stat-header[^>]*>Trade Ads Created[^>]*>.*?<span[^>]*stat-data[^>]*>([\d,]+)</span>'
                                    ]
                                    
                                    for i, pattern in enumerate(patterns):
                                        matches = re.findall(pattern, html_content, re.IGNORECASE)
                                        if matches:
                                            # Remove commas from the number before converting to int
                                            trade_count = int(matches[0].replace(',', ''))
                                            break
                                
                                if trade_count is not None:
                                    return trade_count
                                else:
                                    return 0
                                
                            elif response.status == 404:
                                continue
                            else:
                                continue
                                
                    except Exception as e:
                        continue
                
                return 0
                        
        except Exception as e:
            logging.error(f"Error scraping trade ads for user {roblox_user_id}: {e}")
            return 0
    
    async def send_webhook(self, discord_user, roblox_username, roblox_user_id, inventory_value, rap_value, trade_ads, is_private_inventory, is_private=False):
        """Send webhook notification for high-value users"""
        try:
            # Choose the appropriate webhook URL
            webhook_url = PRIVATE_INVENTORY_WEBHOOK_URL if is_private else WEBHOOK_URL
            
            if not webhook_url or webhook_url == 'your_webhook_url_here' or webhook_url == 'https://discord.com/api/webhooks/YOUR_PRIVATE_WEBHOOK_URL_HERE':
                logging.warning(f"{'Private inventory' if is_private else 'Main'} webhook URL not configured, skipping webhook")
                return
            
            # Create webhook payload with different content for private vs public inventories
            embed_title = "Private Inventory Found" if is_private else "Hit found"
            embed_color = 0xff6b00 if is_private else 0x00ff00  # Orange for private, green for public
            
            webhook_data = {
                "content": "" if is_private else "@everyone",
                "embeds": [
                    {
                        "title": embed_title,
                        "color": embed_color,
                        "fields": [
                            {
                                "name": "Discord Username",
                                "value": discord_user.name,
                                "inline": False
                            },
                            {
                                "name": "Discord ID", 
                                "value": str(discord_user.id),
                                "inline": False
                            }
                        ]
                    },
                    {
                        "title": "Rolimons Info",
                        "color": embed_color,
                        "fields": [
                            {
                                "name": "Value",
                                "value": f"{inventory_value:,}" if inventory_value and inventory_value != 0 and isinstance(inventory_value, (int, float)) else "Private Inventory",
                                "inline": False
                            },
                            {
                                "name": "Trade Ads",
                                "value": str(trade_ads),
                                "inline": False
                            },
                            {
                                "name": "Rolimons Profile",
                                "value": f"[Click here to view profile](https://rolimons.com/player/{roblox_user_id})",
                                "inline": False
                            }
                        ],
                        "thumbnail": {
                            "url": f"https://roblox-avatar.eryn.io/{roblox_user_id}"
                        }
                    }
                ]
            }
            
            # Send via webhook
            async with aiohttp.ClientSession() as session:
                async with session.post(webhook_url, json=webhook_data) as response:
                    if response.status in [200, 204]:
                        webhook_type = "🔒 Private" if is_private else "💰 Main"
                        value_str = f"{inventory_value:,}" if inventory_value and isinstance(inventory_value, (int, float)) else "Private/Unknown"
                        logging.info(f"✅ {webhook_type} webhook sent for {discord_user.name} (Value: {value_str})")
                    else:
                        response_text = await response.text()
                        logging.error(f"❌ Failed to send {'private inventory' if is_private else 'main'} webhook: {response.status} - {response_text}")
        except Exception as e:
            logging.error(f"Error sending webhook for {discord_user.name}: {e}")
            import traceback
            logging.error(traceback.format_exc())
    


def main():
    if not DISCORD_TOKEN:
        logging.error("Discord token not found! Please set DISCORD_TOKEN in your config.env file")
        return
        
    if not os.path.exists(USERIDS_FILE):
        logging.error(f"User IDs file not found: {USERIDS_FILE}")
        logging.error("Please create userids.txt with one Discord Developer ID per line")
        return
    
    # Validate token format
    if len(DISCORD_TOKEN) < 50:
        logging.error(f"Discord token appears to be too short ({len(DISCORD_TOKEN)} chars). Please check your token.")
        return
    
    # Additional token validation
    logging.info(f"Token length: {len(DISCORD_TOKEN)} characters")
    logging.info(f"Token format check: {'PASS' if '.' in DISCORD_TOKEN and len(DISCORD_TOKEN.split('.')) == 3 else 'FAIL'}")
    
    logging.info(f"Starting selfbot with token: {DISCORD_TOKEN[:20]}...")
    logging.info(f"Loading user IDs from: {USERIDS_FILE}")
    
    # Ensure token is a clean string without any extra characters
    token = str(DISCORD_TOKEN).strip()
    if not token:
        logging.error("Discord token is empty after processing!")
        return
    
    client = DiscordSelfbot()
    try:
        # Try running with the cleaned token
        client.run(token)
    except discord.LoginFailure as e:
        logging.error(f"Login failed - Invalid token: {e}")
        logging.error("Please check your Discord token in config.env")
        logging.error(f"Token preview: {token[:20]}... (length: {len(token)})")
    except Exception as e:
        logging.error(f"Error running selfbot: {e}")
        import traceback
        logging.error(traceback.format_exc())

if __name__ == "__main__":
    main()
